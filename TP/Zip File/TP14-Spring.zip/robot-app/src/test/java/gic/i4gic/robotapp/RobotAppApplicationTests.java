package gic.i4gic.robotapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RobotAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
