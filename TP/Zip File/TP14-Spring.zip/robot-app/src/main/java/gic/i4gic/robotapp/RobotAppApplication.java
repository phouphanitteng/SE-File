package gic.i4gic.robotapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RobotAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RobotAppApplication.class, args);
	}

}
